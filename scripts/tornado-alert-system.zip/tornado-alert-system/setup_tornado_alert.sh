#!/bin/bash
# ===============================================================================
# TORNADO WARNING ALERT SYSTEM - Instalación
# ===============================================================================
# Ejecutar como: sudo bash setup_tornado_alert.sh

set -e

echo "🌪️ Instalando Tornado Warning Alert System..."
echo "================================================"

# Directorio de instalación
INSTALL_DIR="/opt/canalmeteo"
SCRIPTS_DIR="$INSTALL_DIR/scripts"
DATA_DIR="$INSTALL_DIR/data/tornado"
LOG_DIR="/var/log/canalmeteo"
VENV_DIR="$INSTALL_DIR/env"

# Crear directorios
echo "📁 Creando directorios..."
mkdir -p "$SCRIPTS_DIR"
mkdir -p "$DATA_DIR/web"
mkdir -p "$LOG_DIR"

# Crear entorno virtual si no existe
if [ ! -d "$VENV_DIR" ]; then
    echo "🐍 Creando entorno virtual Python..."
    python3 -m venv "$VENV_DIR"
fi

# Activar entorno e instalar dependencias
echo "📦 Instalando dependencias Python..."
source "$VENV_DIR/bin/activate"
pip install --upgrade pip
pip install requests python-dotenv paramiko folium pillow twilio sendgrid

# Copiar script
echo "📋 Copiando script principal..."
cp tornado_warning.py "$SCRIPTS_DIR/"
chmod +x "$SCRIPTS_DIR/tornado_warning.py"

# Copiar .env de ejemplo si no existe .env
if [ ! -f "$SCRIPTS_DIR/.env" ]; then
    echo "⚙️ Copiando configuración de ejemplo..."
    cp tornado_warning.env.example "$SCRIPTS_DIR/.env"
    echo "   ⚠️ IMPORTANTE: Edita $SCRIPTS_DIR/.env con tus credenciales"
fi

# Crear wrapper script
echo "🔧 Creando script wrapper..."
cat > "$SCRIPTS_DIR/run_tornado_alert.sh" << 'WRAPPER'
#!/bin/bash
cd /opt/canalmeteo/scripts
source /opt/canalmeteo/env/bin/activate
export $(cat .env | grep -v '^#' | xargs)
python3 tornado_warning.py "$@"
WRAPPER
chmod +x "$SCRIPTS_DIR/run_tornado_alert.sh"

# Configurar crontab
echo "⏰ Configurando crontab..."
CRON_JOB="* * * * * $SCRIPTS_DIR/run_tornado_alert.sh >> $LOG_DIR/tornado.log 2>&1"

# Verificar si ya existe el cron
if ! crontab -l 2>/dev/null | grep -q "tornado_warning"; then
    (crontab -l 2>/dev/null; echo "$CRON_JOB") | crontab -
    echo "   ✅ Crontab configurado (cada minuto)"
else
    echo "   ℹ️ Crontab ya configurado"
fi

# Crear servicio systemd (opcional, para modo daemon)
echo "🔄 Creando servicio systemd (opcional)..."
cat > /etc/systemd/system/tornado-alert.service << SERVICE
[Unit]
Description=Tornado Warning Alert System
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=$SCRIPTS_DIR
EnvironmentFile=$SCRIPTS_DIR/.env
ExecStart=$VENV_DIR/bin/python3 $SCRIPTS_DIR/tornado_warning.py --daemon
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
SERVICE

systemctl daemon-reload
echo "   Para usar como servicio: systemctl enable tornado-alert && systemctl start tornado-alert"

# Resumen
echo ""
echo "================================================"
echo "✅ Instalación completada!"
echo "================================================"
echo ""
echo "📁 Archivos instalados:"
echo "   - Script: $SCRIPTS_DIR/tornado_warning.py"
echo "   - Config: $SCRIPTS_DIR/.env"
echo "   - Wrapper: $SCRIPTS_DIR/run_tornado_alert.sh"
echo "   - Datos: $DATA_DIR/"
echo "   - Logs: $LOG_DIR/tornado.log"
echo ""
echo "⚙️ SIGUIENTE PASO:"
echo "   1. Edita $SCRIPTS_DIR/.env con tus credenciales"
echo "   2. Prueba manualmente: $SCRIPTS_DIR/run_tornado_alert.sh"
echo "   3. Revisa logs: tail -f $LOG_DIR/tornado.log"
echo ""
echo "📱 Para habilitar SMS, configura Twilio en .env"
echo "📧 Para habilitar Email, configura SendGrid en .env"
echo ""
