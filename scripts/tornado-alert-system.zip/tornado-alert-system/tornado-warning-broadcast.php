<?php
/**
 * TORNADO WARNING - Canal Meteo TV
 * Template para pantalla de broadcast/overlay
 * 
 * Ubicación: /lynx/web/tornado-warning.php
 * Tamaño: 1920x1080 (Full HD vertical para broadcast)
 */

// Obtener datos del tornado warning más reciente
$dataUrl = 'https://canalmeteo-public.sfo3.digitaloceanspaces.com/alertas/tornado/latest.json';
$data = @json_decode(@file_get_contents($dataUrl), true);

// Si no hay datos, mostrar pantalla de espera
if (!$data) {
    $data = [
        'active' => false,
        'message' => 'No hay Tornado Warnings activos'
    ];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🌪️ Tornado Warning | Canal Meteo TV</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: linear-gradient(180deg, #0f0f1a 0%, #1a1a2e 50%, #16213e 100%);
            min-height: 100vh;
            color: white;
            overflow: hidden;
        }
        
        /* Pantalla completa para broadcast */
        .broadcast-container {
            width: 1080px;
            height: 1920px;
            margin: 0 auto;
            position: relative;
            overflow: hidden;
        }
        
        /* Header de emergencia */
        .emergency-header {
            background: linear-gradient(135deg, #dc2626 0%, #991b1b 50%, #7f1d1d 100%);
            padding: 40px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        
        .emergency-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 200%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent);
            animation: shine 3s infinite;
        }
        
        @keyframes shine {
            0% { transform: translateX(-50%); }
            100% { transform: translateX(50%); }
        }
        
        .emergency-label {
            display: inline-flex;
            align-items: center;
            gap: 15px;
            background: rgba(0, 0, 0, 0.3);
            padding: 12px 30px;
            border-radius: 50px;
            margin-bottom: 20px;
        }
        
        .pulse-dot {
            width: 16px;
            height: 16px;
            background: #fef08a;
            border-radius: 50%;
            animation: pulse 1.5s ease-in-out infinite;
        }
        
        @keyframes pulse {
            0%, 100% { transform: scale(1); opacity: 1; }
            50% { transform: scale(1.3); opacity: 0.7; }
        }
        
        .emergency-label span {
            font-size: 24px;
            font-weight: 700;
            letter-spacing: 3px;
            text-transform: uppercase;
        }
        
        .emergency-title {
            font-size: 72px;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 4px;
            text-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 20px;
        }
        
        .tornado-icon {
            font-size: 80px;
            animation: spin 4s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        /* Contenido principal */
        .content {
            padding: 40px;
            flex: 1;
        }
        
        /* Área afectada */
        .area-section {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            border: 2px solid rgba(220, 38, 38, 0.5);
        }
        
        .section-label {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 20px;
            font-weight: 600;
            color: #60a5fa;
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-bottom: 20px;
        }
        
        .area-text {
            font-size: 36px;
            font-weight: 700;
            line-height: 1.4;
            color: #f1f5f9;
        }
        
        /* Mapa */
        .map-section {
            background: rgba(0, 0, 0, 0.3);
            border-radius: 20px;
            overflow: hidden;
            height: 500px;
            margin-bottom: 30px;
            position: relative;
        }
        
        .map-section iframe {
            width: 100%;
            height: 100%;
            border: none;
        }
        
        .map-overlay {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            background: linear-gradient(transparent, rgba(0,0,0,0.8));
            padding: 20px;
        }
        
        /* Información de tiempo */
        .time-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .time-card {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 16px;
            padding: 25px;
            text-align: center;
        }
        
        .time-card.expires {
            background: rgba(220, 38, 38, 0.2);
            border: 2px solid rgba(220, 38, 38, 0.5);
        }
        
        .time-label {
            font-size: 16px;
            color: #94a3b8;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 10px;
        }
        
        .time-value {
            font-size: 42px;
            font-weight: 800;
            color: white;
        }
        
        .time-card.expires .time-value {
            color: #fca5a5;
        }
        
        /* Instrucciones */
        .instructions {
            background: linear-gradient(135deg, rgba(251, 191, 36, 0.1), rgba(245, 158, 11, 0.05));
            border-left: 6px solid #fbbf24;
            border-radius: 0 16px 16px 0;
            padding: 30px;
            margin-bottom: 30px;
        }
        
        .instructions h3 {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 24px;
            color: #fbbf24;
            margin-bottom: 15px;
        }
        
        .instructions p {
            font-size: 28px;
            line-height: 1.5;
            color: #fef3c7;
        }
        
        /* Footer */
        .footer {
            background: rgba(0, 0, 0, 0.5);
            padding: 30px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
        }
        
        .footer-logo {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .footer-logo img {
            height: 50px;
        }
        
        .footer-logo span {
            font-size: 24px;
            font-weight: 700;
            color: #60a5fa;
        }
        
        .footer-source {
            text-align: right;
            color: #64748b;
            font-size: 18px;
        }
        
        .footer-source a {
            color: #60a5fa;
            text-decoration: none;
        }
        
        /* Estado inactivo */
        .inactive-state {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            text-align: center;
            padding: 40px;
        }
        
        .inactive-icon {
            font-size: 120px;
            margin-bottom: 30px;
            opacity: 0.5;
        }
        
        .inactive-text {
            font-size: 36px;
            color: #64748b;
        }
        
        /* Animación de urgencia */
        @keyframes urgency-border {
            0%, 100% { border-color: rgba(220, 38, 38, 0.5); }
            50% { border-color: rgba(220, 38, 38, 1); }
        }
        
        .area-section {
            animation: urgency-border 2s ease-in-out infinite;
        }
    </style>
</head>
<body>
    <div class="broadcast-container">
        <?php if (isset($data['active']) && $data['active']): ?>
        
        <!-- Header de emergencia -->
        <div class="emergency-header">
            <div class="emergency-label">
                <div class="pulse-dot"></div>
                <span>Alerta Activa</span>
            </div>
            <h1 class="emergency-title">
                <span class="tornado-icon">🌪️</span>
                TORNADO WARNING
            </h1>
        </div>
        
        <!-- Contenido -->
        <div class="content">
            <!-- Área afectada -->
            <div class="area-section">
                <div class="section-label">
                    <span>📍</span>
                    Área Afectada
                </div>
                <p class="area-text"><?php echo htmlspecialchars($data['areas'] ?? 'Área no especificada'); ?></p>
            </div>
            
            <!-- Mapa -->
            <div class="map-section">
                <?php if (isset($data['map_url'])): ?>
                <iframe src="<?php echo htmlspecialchars($data['map_url']); ?>"></iframe>
                <?php else: ?>
                <div style="display: flex; align-items: center; justify-content: center; height: 100%; color: #64748b;">
                    Mapa no disponible
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Tiempos -->
            <div class="time-grid">
                <div class="time-card">
                    <div class="time-label">Emitido</div>
                    <div class="time-value"><?php echo date('H:i', strtotime($data['effective'] ?? 'now')); ?></div>
                </div>
                <div class="time-card expires">
                    <div class="time-label">⏰ Expira</div>
                    <div class="time-value"><?php echo date('H:i', strtotime($data['expires'] ?? 'now')); ?></div>
                </div>
            </div>
            
            <!-- Instrucciones -->
            <?php if (!empty($data['instruction'])): ?>
            <div class="instructions">
                <h3>
                    <span>⚠️</span>
                    Instrucciones de Seguridad
                </h3>
                <p><?php echo nl2br(htmlspecialchars(substr($data['instruction'], 0, 300))); ?></p>
            </div>
            <?php else: ?>
            <div class="instructions">
                <h3>
                    <span>⚠️</span>
                    Busque Refugio Inmediatamente
                </h3>
                <p>Diríjase al sótano o habitación interior en el piso más bajo. Aléjese de ventanas, puertas y paredes exteriores.</p>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- Footer -->
        <div class="footer">
            <div class="footer-logo">
                <span>Canal Meteo TV</span>
            </div>
            <div class="footer-source">
                Fuente: <a href="https://www.weather.gov" target="_blank">National Weather Service</a>
            </div>
        </div>
        
        <?php else: ?>
        
        <!-- Estado inactivo -->
        <div class="inactive-state">
            <div class="inactive-icon">🌪️</div>
            <p class="inactive-text"><?php echo htmlspecialchars($data['message'] ?? 'No hay alertas activas'); ?></p>
        </div>
        
        <?php endif; ?>
    </div>
    
    <!-- Auto-refresh cada 30 segundos -->
    <script>
        setTimeout(() => location.reload(), 30000);
    </script>
</body>
</html>
