# 🌪️ Sistema de Alertas de Tornado Warning - Canal Meteo TV

Sistema automatizado para detectar Tornado Warnings del National Weather Service (NWS), generar mapas, y enviar notificaciones por email y SMS.

## 📋 Características

- ✅ Monitoreo automático de Tornado Warnings activos
- ✅ Generación de mapas interactivos con polígono del área afectada
- ✅ Imágenes PNG para adjuntar a notificaciones
- ✅ Páginas HTML con toda la información de la alerta
- ✅ Notificaciones por email (SendGrid)
- ✅ Notificaciones por SMS (Twilio)
- ✅ Subida automática a DigitalOcean Spaces y SFTP
- ✅ Template PHP para broadcast/overlay en OBS
- ✅ Cache para evitar procesar la misma alerta múltiples veces

## 📁 Archivos Incluidos

```
tornado-alert-system/
├── tornado_warning.py          # Script principal
├── tornado_warning.env.example # Configuración de ejemplo
├── setup_tornado_alert.sh      # Script de instalación
├── tornado-warning-broadcast.php # Template para broadcast
└── README.md                   # Este archivo
```

## 🚀 Instalación Rápida

### 1. Copiar archivos al servidor

```bash
scp -r tornado-alert-system/ usuario@servidor:/opt/canalmeteo/scripts/
```

### 2. Ejecutar instalador

```bash
ssh usuario@servidor
cd /opt/canalmeteo/scripts
sudo bash setup_tornado_alert.sh
```

### 3. Configurar credenciales

```bash
nano /opt/canalmeteo/scripts/.env
```

Edita el archivo `.env` con tus credenciales:

```env
# SFTP
SFTP_HOST=tu-servidor.com
SFTP_USER=tu_usuario
SFTP_PASS=tu_password

# SendGrid (email)
SENDGRID_API_KEY=SG.xxxxx
FROM_EMAIL=alertas@canalmeteo.tv
TO_EMAILS=tu@email.com,otro@email.com

# Twilio (SMS)
TWILIO_ACCOUNT_SID=ACxxxxx
TWILIO_AUTH_TOKEN=xxxxx
TWILIO_FROM_NUMBER=+1234567890
SMS_TO_NUMBERS=+1234567890
```

### 4. Probar manualmente

```bash
/opt/canalmeteo/scripts/run_tornado_alert.sh
```

### 5. Verificar crontab

```bash
crontab -l
# Debería mostrar:
# * * * * * /opt/canalmeteo/scripts/run_tornado_alert.sh >> /var/log/canalmeteo/tornado.log 2>&1
```

## 📱 Configuración de Notificaciones

### Email con SendGrid

1. Crea una cuenta en [SendGrid](https://sendgrid.com/)
2. Ve a Settings → API Keys → Create API Key
3. Verifica tu dominio de envío
4. Añade las credenciales al `.env`

### SMS con Twilio

1. Crea una cuenta en [Twilio](https://www.twilio.com/)
2. Obtén un número de teléfono
3. Copia Account SID y Auth Token
4. Añade las credenciales al `.env`

**Nota:** Twilio cobra por SMS enviado (~$0.0075 por SMS en EEUU)

## 🖥️ Template de Broadcast

El archivo `tornado-warning-broadcast.php` está diseñado para mostrar en pantalla completa (1080x1920 vertical) la información del tornado warning activo.

### Uso en OBS Studio

1. Sube `tornado-warning-broadcast.php` a tu servidor web
2. En OBS, añade una fuente "Navegador"
3. URL: `https://tu-servidor.com/lynx/tornado-warning.php`
4. Tamaño: 1080x1920
5. Actualización: 30 segundos (automático)

## 🔧 Configuración Avanzada

### Cambiar tipos de alerta monitoreados

En `tornado_warning.py`, modifica:

```python
CONFIG = {
    'alert_types': ['Tornado Warning'],  # Añadir más:
    # 'alert_types': ['Tornado Warning', 'Tornado Watch', 'Severe Thunderstorm Warning'],
}
```

### Cambiar intervalo de verificación

```python
CONFIG = {
    'check_interval': 60,  # segundos (default: 1 minuto)
}
```

### Ejecutar como servicio (daemon)

```bash
# Habilitar servicio
sudo systemctl enable tornado-alert
sudo systemctl start tornado-alert

# Ver logs
sudo journalctl -u tornado-alert -f
```

## 📊 Estructura de Datos

### JSON de alerta (`latest.json`)

```json
{
  "active": true,
  "id": "urn:oid:2.49.0.1.840.0...",
  "event": "Tornado Warning",
  "areas": "Condado de Example, TX",
  "headline": "Tornado Warning issued...",
  "effective": "2024-01-15T18:30:00-06:00",
  "expires": "2024-01-15T19:15:00-06:00",
  "instruction": "TAKE COVER NOW!...",
  "center": [35.1234, -97.5678],
  "map_url": "https://canalmeteo-public.../mapa_abc123.html"
}
```

## 🗂️ Directorios

| Directorio | Contenido |
|------------|-----------|
| `/opt/canalmeteo/scripts/` | Script principal y .env |
| `/opt/canalmeteo/data/tornado/` | Cache y datos |
| `/opt/canalmeteo/data/tornado/web/` | HTMLs y PNGs generados |
| `/var/log/canalmeteo/` | Logs |

## 📡 URLs Públicas (Spaces)

- Mapa interactivo: `https://canalmeteo-public.sfo3.digitaloceanspaces.com/alertas/tornado/mapa_{hash}.html`
- Imagen PNG: `https://canalmeteo-public.sfo3.digitaloceanspaces.com/alertas/tornado/mapa_{hash}.png`
- Página de alerta: `https://canalmeteo-public.sfo3.digitaloceanspaces.com/alertas/tornado/tornado_{hash}.html`
- Último warning: `https://canalmeteo-public.sfo3.digitaloceanspaces.com/alertas/tornado/latest.json`

## 🔍 Troubleshooting

### No se envían emails

```bash
# Verificar configuración
grep SENDGRID /opt/canalmeteo/scripts/.env

# Probar conexión
python3 -c "from sendgrid import SendGridAPIClient; print('OK')"
```

### No se envían SMS

```bash
# Verificar Twilio
grep TWILIO /opt/canalmeteo/scripts/.env

# Probar conexión
python3 -c "from twilio.rest import Client; print('OK')"
```

### Ver logs en tiempo real

```bash
tail -f /var/log/canalmeteo/tornado.log
```

### Forzar reprocesamiento

```bash
# Borrar cache
rm /opt/canalmeteo/data/tornado/processed_alerts.json

# Ejecutar de nuevo
/opt/canalmeteo/scripts/run_tornado_alert.sh
```

## 📞 Soporte

- Email: contacto@canalmeteo.tv
- Web: https://www.canalmeteo.tv

## 📜 Licencia

Este código es propiedad de Canal Meteo TV. Uso interno únicamente.

---

Desarrollado con ❤️ para Canal Meteo TV
