#!/usr/bin/env python3
"""
YouTube Analytics Exporter
===========================
Exporta los datos de SQLite a JSON y los sube a DigitalOcean Spaces.

Uso:
    python3 youtube_exporter.py              # Exporta y sube todo
    python3 youtube_exporter.py --local      # Solo genera JSON localmente
    python3 youtube_exporter.py --days 30    # Últimos 30 días (default)
"""

import os
import sys
import json
import sqlite3
import subprocess
import argparse
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Any

# Configuración de rutas
SCRIPT_DIR = Path(__file__).parent.parent
CONFIG_DIR = SCRIPT_DIR / "config"
DATA_DIR = SCRIPT_DIR / "data"
EXPORT_DIR = DATA_DIR / "exports"

DATABASE_FILE = DATA_DIR / "youtube_analytics.db"

# DigitalOcean Spaces config (ajustar según tu configuración)
SPACES_BUCKET = "canalmeteo-data"
SPACES_ENDPOINT = "https://nyc3.digitaloceanspaces.com"
SPACES_PATH = "analytics/youtube"


class YouTubeExporter:
    """Exportador de datos de YouTube Analytics"""
    
    def __init__(self, db_path: Path = DATABASE_FILE):
        self.db_path = db_path
        self.conn = None
        
    def connect(self) -> bool:
        """Conecta a la base de datos"""
        if not self.db_path.exists():
            print(f"ERROR: Base de datos no encontrada: {self.db_path}")
            print("Ejecuta primero: python3 youtube_daily_collector.py --backfill 30")
            return False
        
        self.conn = sqlite3.connect(self.db_path)
        self.conn.row_factory = sqlite3.Row
        return True
    
    def get_channel_summary(self, days: int = 30) -> Dict[str, Any]:
        """Genera resumen del canal"""
        
        cursor = self.conn.cursor()
        start_date = (datetime.now() - timedelta(days=days)).strftime('%Y-%m-%d')
        
        # Datos diarios
        cursor.execute('''
            SELECT * FROM channel_daily
            WHERE date >= ?
            ORDER BY date DESC
        ''', (start_date,))
        
        daily_data = [dict(row) for row in cursor.fetchall()]
        
        # Último snapshot
        cursor.execute('''
            SELECT * FROM channel_snapshots
            ORDER BY date DESC
            LIMIT 1
        ''')
        row = cursor.fetchone()
        latest_snapshot = dict(row) if row else None
        
        # Calcular totales del período
        cursor.execute('''
            SELECT 
                SUM(views) as total_views,
                SUM(estimated_minutes_watched) as total_watch_time,
                SUM(subscribers_gained) as total_subs_gained,
                SUM(subscribers_lost) as total_subs_lost,
                SUM(net_subscribers) as net_subs,
                SUM(likes) as total_likes,
                SUM(comments) as total_comments,
                SUM(shares) as total_shares,
                AVG(average_view_duration) as avg_view_duration,
                COUNT(*) as days_with_data
            FROM channel_daily
            WHERE date >= ?
        ''', (start_date,))
        
        period_totals = dict(cursor.fetchone())
        
        # Calcular tendencias (comparar últimos 7 días vs 7 anteriores)
        cursor.execute('''
            SELECT 
                SUM(CASE WHEN date >= date('now', '-7 days') THEN views ELSE 0 END) as recent_views,
                SUM(CASE WHEN date >= date('now', '-14 days') AND date < date('now', '-7 days') THEN views ELSE 0 END) as previous_views,
                SUM(CASE WHEN date >= date('now', '-7 days') THEN net_subscribers ELSE 0 END) as recent_subs,
                SUM(CASE WHEN date >= date('now', '-14 days') AND date < date('now', '-7 days') THEN net_subscribers ELSE 0 END) as previous_subs
            FROM channel_daily
        ''')
        
        trends_data = dict(cursor.fetchone())
        
        # Calcular porcentaje de cambio
        def calc_trend(recent, previous):
            if previous and previous > 0:
                return round(((recent - previous) / previous) * 100, 1)
            return None
        
        trends = {
            'views_trend_pct': calc_trend(trends_data['recent_views'], trends_data['previous_views']),
            'subs_trend_pct': calc_trend(trends_data['recent_subs'], trends_data['previous_subs'])
        }
        
        return {
            'generated_at': datetime.utcnow().isoformat(),
            'period_days': days,
            'current_stats': latest_snapshot,
            'period_totals': period_totals,
            'trends': trends,
            'daily_data': daily_data
        }
    
    def get_top_videos(self, days: int = 30, limit: int = 20) -> List[Dict]:
        """Obtiene los videos con mejor rendimiento"""
        
        cursor = self.conn.cursor()
        start_date = (datetime.now() - timedelta(days=days)).strftime('%Y-%m-%d')
        
        cursor.execute('''
            SELECT 
                v.video_id,
                v.title,
                v.published_at,
                v.duration,
                v.thumbnail_url,
                v.total_views,
                v.total_likes,
                v.total_comments,
                SUM(vd.views) as period_views,
                SUM(vd.estimated_minutes_watched) as period_watch_time,
                SUM(vd.likes) as period_likes,
                SUM(vd.subscribers_gained) as period_subs_gained,
                AVG(vd.average_view_percentage) as avg_retention,
                COUNT(vd.date) as days_active
            FROM videos v
            LEFT JOIN video_daily vd ON v.video_id = vd.video_id AND vd.date >= ?
            GROUP BY v.video_id
            ORDER BY period_views DESC
            LIMIT ?
        ''', (start_date, limit))
        
        return [dict(row) for row in cursor.fetchall()]
    
    def get_video_performance(self, video_id: str, days: int = 30) -> Dict:
        """Obtiene el rendimiento detallado de un video"""
        
        cursor = self.conn.cursor()
        start_date = (datetime.now() - timedelta(days=days)).strftime('%Y-%m-%d')
        
        # Metadatos del video
        cursor.execute('SELECT * FROM videos WHERE video_id = ?', (video_id,))
        row = cursor.fetchone()
        metadata = dict(row) if row else {}
        
        # Datos diarios
        cursor.execute('''
            SELECT * FROM video_daily
            WHERE video_id = ? AND date >= ?
            ORDER BY date DESC
        ''', (video_id, start_date))
        
        daily_data = [dict(row) for row in cursor.fetchall()]
        
        return {
            'video_id': video_id,
            'metadata': metadata,
            'daily_data': daily_data
        }
    
    def export_all(self, days: int = 30) -> Dict[str, Path]:
        """Exporta todos los datos a archivos JSON"""
        
        EXPORT_DIR.mkdir(parents=True, exist_ok=True)
        exported_files = {}
        
        # 1. Resumen del canal
        print("Exportando resumen del canal...")
        channel_summary = self.get_channel_summary(days)
        channel_file = EXPORT_DIR / "youtube_channel_summary.json"
        with open(channel_file, 'w', encoding='utf-8') as f:
            json.dump(channel_summary, f, indent=2, ensure_ascii=False)
        exported_files['channel_summary'] = channel_file
        
        # 2. Top videos
        print("Exportando top videos...")
        top_videos = self.get_top_videos(days)
        videos_file = EXPORT_DIR / "youtube_top_videos.json"
        with open(videos_file, 'w', encoding='utf-8') as f:
            json.dump({
                'generated_at': datetime.utcnow().isoformat(),
                'period_days': days,
                'videos': top_videos
            }, f, indent=2, ensure_ascii=False)
        exported_files['top_videos'] = videos_file
        
        # 3. Dashboard data (datos combinados para visualización rápida)
        print("Exportando datos para dashboard...")
        dashboard_data = {
            'generated_at': datetime.utcnow().isoformat(),
            'period_days': days,
            'channel': {
                'current': channel_summary.get('current_stats'),
                'period_totals': channel_summary.get('period_totals'),
                'trends': channel_summary.get('trends')
            },
            'top_videos': top_videos[:10],  # Solo top 10 para el dashboard
            'daily_views': [
                {'date': d['date'], 'views': d['views'], 'watch_time': d['estimated_minutes_watched']}
                for d in channel_summary.get('daily_data', [])
            ],
            'daily_subscribers': [
                {'date': d['date'], 'gained': d['subscribers_gained'], 'lost': d['subscribers_lost'], 'net': d['net_subscribers']}
                for d in channel_summary.get('daily_data', [])
            ]
        }
        dashboard_file = EXPORT_DIR / "youtube_dashboard.json"
        with open(dashboard_file, 'w', encoding='utf-8') as f:
            json.dump(dashboard_data, f, indent=2, ensure_ascii=False)
        exported_files['dashboard'] = dashboard_file
        
        print(f"\nArchivos exportados en: {EXPORT_DIR}")
        for name, path in exported_files.items():
            print(f"  - {name}: {path.name}")
        
        return exported_files
    
    def upload_to_spaces(self, files: Dict[str, Path]) -> bool:
        """Sube los archivos a DigitalOcean Spaces usando AWS CLI"""
        
        print("\nSubiendo a DigitalOcean Spaces...")
        
        # Verificar que aws cli esté configurado
        try:
            result = subprocess.run(
                ['aws', 's3', 'ls', f's3://{SPACES_BUCKET}', 
                 '--endpoint-url', SPACES_ENDPOINT],
                capture_output=True,
                text=True
            )
            if result.returncode != 0:
                print(f"ERROR: No se puede acceder a Spaces. Verifica la configuración de AWS CLI.")
                print(f"Stderr: {result.stderr}")
                return False
        except FileNotFoundError:
            print("ERROR: AWS CLI no está instalado.")
            return False
        
        # Subir cada archivo
        success = True
        for name, local_path in files.items():
            remote_path = f"s3://{SPACES_BUCKET}/{SPACES_PATH}/{local_path.name}"
            
            cmd = [
                'aws', 's3', 'cp',
                str(local_path),
                remote_path,
                '--endpoint-url', SPACES_ENDPOINT,
                '--acl', 'public-read',
                '--content-type', 'application/json'
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                print(f"  ✓ {local_path.name}")
            else:
                print(f"  ✗ {local_path.name}: {result.stderr}")
                success = False
        
        if success:
            cdn_base = f"https://{SPACES_BUCKET}.nyc3.cdn.digitaloceanspaces.com/{SPACES_PATH}"
            print(f"\nArchivos disponibles en:")
            for name, local_path in files.items():
                print(f"  {cdn_base}/{local_path.name}")
        
        return success
    
    def close(self):
        """Cierra la conexión"""
        if self.conn:
            self.conn.close()


def main():
    parser = argparse.ArgumentParser(description='YouTube Analytics Exporter')
    parser.add_argument('--days', type=int, default=30, help='Días de datos a exportar (default: 30)')
    parser.add_argument('--local', action='store_true', help='Solo exportar localmente, no subir a Spaces')
    args = parser.parse_args()
    
    exporter = YouTubeExporter()
    
    try:
        if not exporter.connect():
            sys.exit(1)
        
        # Exportar datos
        files = exporter.export_all(args.days)
        
        # Subir a Spaces (si no es --local)
        if not args.local:
            exporter.upload_to_spaces(files)
        
    except Exception as e:
        print(f"ERROR: {e}")
        sys.exit(1)
    finally:
        exporter.close()


if __name__ == '__main__':
    main()
