import { Config } from "@remotion/cli/config";

Config.setVideoImageFormat("jpeg");
Config.setOverwriteOutput(true);
// El render a escala completa (1920x1080) se controla con --scale=1 en render.sh,
// igual que en parques-webcams. En sfo3-c usar --concurrency=3 (4 provoca OOM).
