import React, { useEffect, useRef } from "react";
import {
  AbsoluteFill,
  continueRender,
  delayRender,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import mapboxgl from "mapbox-gl";
import "mapbox-gl/dist/mapbox-gl.css";
import { MAPBOX_TOKEN, MAPBOX_STYLE } from "../lib/cdn";
import { SatView } from "../types";

type Props = {
  sat: SatView;
  center: [number, number];
  zoom: number;
  opacity?: number;
};

// Mapa Mapbox dentro de Remotion: drapea los frames del satélite (image source
// por bounds del manifest) y conmuta opacidad por frame. preserveDrawingBuffer
// es OBLIGATORIO para que Remotion capture el canvas en el render.
export const SatMap: React.FC<Props> = ({ sat, center, zoom, opacity = 0.9 }) => {
  const ref = useRef<HTMLDivElement>(null);
  const mapRef = useRef<mapboxgl.Map | null>(null);
  const readyRef = useRef(false);
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();

  const n = sat.frames.length;
  const idx = n
    ? Math.min(n - 1, Math.floor((frame / Math.max(1, durationInFrames - 1)) * (n - 1)))
    : 0;

  // Init del mapa (una vez)
  useEffect(() => {
    if (!ref.current || !sat.bounds || !n) return;
    const handle = delayRender("sat-map-init");
    mapboxgl.accessToken = MAPBOX_TOKEN;
    const b = sat.bounds;
    const coords: [[number, number], [number, number], [number, number], [number, number]] = [
      [b.west, b.north],
      [b.east, b.north],
      [b.east, b.south],
      [b.west, b.south],
    ];

    const map = new mapboxgl.Map({
      container: ref.current,
      style: MAPBOX_STYLE,
      center,
      zoom,
      interactive: false,
      attributionControl: false,
      preserveDrawingBuffer: true, // imprescindible para el render
      fadeDuration: 0,
      projection: "mercator",
    });
    mapRef.current = map;

    map.on("load", () => {
      sat.frames.forEach((f, i) => {
        const sid = `sat-${i}`;
        map.addSource(sid, { type: "image", url: f.url, coordinates: coords });
        map.addLayer({
          id: sid,
          type: "raster",
          source: sid,
          paint: { "raster-opacity": 0, "raster-fade-duration": 0 },
        });
      });
      const onIdle = () => {
        readyRef.current = true;
        map.off("idle", onIdle);
        continueRender(handle);
      };
      map.on("idle", onIdle);
    });

    return () => {
      try {
        continueRender(handle);
      } catch {
        /* noop */
      }
      map.remove();
      mapRef.current = null;
      readyRef.current = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Conmutar frame visible y esperar a que el mapa repinte antes de capturar
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !readyRef.current || !n) return;
    const handle = delayRender(`sat-frame-${idx}`);
    sat.frames.forEach((_, i) =>
      map.setPaintProperty(`sat-${i}`, "raster-opacity", i === idx ? opacity : 0)
    );
    const onIdle = () => {
      map.off("idle", onIdle);
      continueRender(handle);
    };
    map.on("idle", onIdle);
    return () => {
      try {
        continueRender(handle);
      } catch {
        /* noop */
      }
    };
  }, [idx, n, opacity]);

  if (!sat.bounds || !n) {
    return (
      <AbsoluteFill
        style={{
          background: "#0d1a26",
          color: "#90a4ae",
          justifyContent: "center",
          alignItems: "center",
          fontSize: 24,
        }}
      >
        Sin frames de satélite (manifest vacío)
      </AbsoluteFill>
    );
  }

  return (
    <AbsoluteFill style={{ background: "#000" }}>
      <div ref={ref} style={{ position: "absolute", inset: 0 }} />
    </AbsoluteFill>
  );
};
