import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { loadFont } from "@remotion/google-fonts/Outfit";
import { Storm } from "../types";
import {
  catKeyFromKt,
  ktToMph,
  tropCat,
  tropShortLabel,
  fmtBulletinTime,
} from "../lib/tropical";

const { fontFamily } = loadFont();

export const DataCard: React.FC<{ storm: Storm }> = ({ storm }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const inAnim = spring({ frame, fps, config: { damping: 16 } });
  const x = interpolate(inAnim, [0, 1], [-60, 0]);
  const opacity = interpolate(inAnim, [0, 1], [0, 1]);

  const ck = catKeyFromKt(storm.intensity_kt);
  const cat = tropCat(ck);
  const mph = ktToMph(storm.intensity_kt);
  const textOnChip = ck === "H1" ? "#1a2530" : "#fff";

  return (
    <div
      style={{
        position: "absolute",
        left: 56,
        bottom: 56,
        transform: `translateX(${x}px)`,
        opacity,
        fontFamily,
        width: 420,
        background: "rgba(13,26,38,0.86)",
        backdropFilter: "blur(6px)",
        borderRadius: 16,
        overflow: "hidden",
        boxShadow: "0 12px 40px rgba(0,0,0,0.5)",
        border: "1px solid rgba(255,255,255,0.08)",
      }}
    >
      {/* Cabecera con color de categoría */}
      <div
        style={{
          background: cat.color,
          color: textOnChip,
          padding: "16px 22px",
          display: "flex",
          alignItems: "center",
          gap: 14,
        }}
      >
        <div
          style={{
            width: 44,
            height: 44,
            borderRadius: "50%",
            border: `2.5px solid ${textOnChip}`,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontWeight: 800,
            fontSize: 24,
          }}
        >
          {cat.letter}
        </div>
        <div>
          <div style={{ fontSize: 30, fontWeight: 800, lineHeight: 1 }}>
            {storm.name}
          </div>
          <div style={{ fontSize: 15, fontWeight: 600, opacity: 0.85 }}>
            {tropShortLabel(ck)}
          </div>
        </div>
      </div>

      {/* Cuerpo */}
      <div style={{ padding: "18px 22px", color: "#fff" }}>
        <Row label="Viento máx. sostenido" value={mph != null ? `${mph} mph` : "—"} big />
        {storm.last_update ? (
          <div style={{ marginTop: 12, fontSize: 13, color: "rgba(255,255,255,0.6)" }}>
            Actualizado {fmtBulletinTime(storm.last_update)}
          </div>
        ) : null}
        {/* TODO Fase siguiente: presión y movimiento desde el punto inicial de points.geojson */}
      </div>
    </div>
  );
};

const Row: React.FC<{ label: string; value: string; big?: boolean }> = ({
  label,
  value,
  big,
}) => (
  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
    <span style={{ fontSize: 15, color: "rgba(255,255,255,0.7)" }}>{label}</span>
    <span
      style={{
        fontSize: big ? 34 : 20,
        fontWeight: 800,
        fontFamily: "'JetBrains Mono', monospace",
      }}
    >
      {value}
    </span>
  </div>
);
