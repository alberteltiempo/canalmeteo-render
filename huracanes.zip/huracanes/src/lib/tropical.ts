import { TROP_CAT } from "./theme";

// kt -> mph redondeado a múltiplos de 5 (idéntico a kt_to_mph5 del pipeline)
export function ktToMph(kt: number | null | undefined): number | null {
  const v = Number(kt);
  return isFinite(v) && v < 9000 ? Math.round((v * 1.150779) / 5) * 5 : null;
}

// Intensidad (kt) -> clave de categoría Saffir-Simpson
export function catKeyFromKt(kt: number | null | undefined): string {
  const v = Number(kt) || 0;
  if (v >= 137) return "H5";
  if (v >= 113) return "H4";
  if (v >= 96) return "H3";
  if (v >= 83) return "H2";
  if (v >= 64) return "H1";
  if (v >= 34) return "TS";
  return "TD";
}

export function tropCat(key: string) {
  return TROP_CAT[key] || { color: "#90caf9", letter: "?" };
}

export function tropShortLabel(key: string): string {
  if (key === "TD") return "Depresión tropical";
  if (key === "TS") return "Tormenta tropical";
  const m = /^H([1-5])$/.exec(key);
  if (m) return `Huracán Cat. ${m[1]}`;
  return key;
}

// Formato de hora ET (es-ES) — idéntico al banner del frontend
export function fmtBulletinTime(iso: string): string {
  try {
    const d = new Date(iso);
    return (
      d.toLocaleString("es-ES", {
        timeZone: "America/New_York",
        weekday: "short",
        day: "numeric",
        month: "short",
        hour: "numeric",
        minute: "2-digit",
        hour12: true,
      }) + " ET"
    );
  } catch {
    return iso || "";
  }
}
