import type { ActiveStorms, ScenePlanItem, SatView, SatFrame } from "../types";
import { activeStormsSchema } from "../types";

export const CDN = "https://canalmeteo-public.sfo3.digitaloceanspaces.com";
export const TROP_BASE = `${CDN}/data/tropical`;

// Resuelve una ruta relativa del índice (s.layers.*) a URL absoluta del CDN
export function tropURL(rel: string): string {
  return `${CDN}/${String(rel).replace(/^\//, "")}?ts=${Date.now()}`;
}

export async function fetchActiveStorms(
  signal?: AbortSignal
): Promise<ActiveStorms> {
  try {
    const r = await fetch(`${TROP_BASE}/active_storms.json?ts=${Date.now()}`, {
      signal,
    });
    const raw = await r.json();
    return activeStormsSchema.parse(raw);
  } catch (e) {
    console.warn("[huracanes] no se pudo leer active_storms.json:", e);
    return { storms: [] };
  }
}

export async function fetchGeoJSON(rel: string, signal?: AbortSignal) {
  const r = await fetch(tropURL(rel), { signal });
  return r.json();
}

// ---- Duraciones de cada escena (segundos) ----
export const SCENE_SECONDS = {
  open: 3.5,
  satGlobal: 5,
  stormSat: 6, // satélite zoom + tarjeta de datos
  stormTrack: 6, // trayectoria + cono + avisos
  stormHazard: 5, // peligros (diapositiva grande)
  stormRain: 5, // acumulado de lluvia 96h
  genesis: 5, // áreas de desarrollo
  outro: 4,
} as const;

// Construye el plan de escenas según los datos (timeline dinámico)
export function buildScenePlan(data: ActiveStorms): ScenePlanItem[] {
  const plan: ScenePlanItem[] = [];
  const push = (
    type: ScenePlanItem["type"],
    seconds: number,
    stormIndex?: number
  ) => plan.push({ id: `${type}-${stormIndex ?? "x"}`, type, seconds, stormIndex });

  push("open", SCENE_SECONDS.open);
  push("satGlobal", SCENE_SECONDS.satGlobal);

  const storms = data.storms || [];
  storms.forEach((_, i) => {
    push("stormSat", SCENE_SECONDS.stormSat, i);
    push("stormTrack", SCENE_SECONDS.stormTrack, i);
    push("stormHazard", SCENE_SECONDS.stormHazard, i);
    push("stormRain", SCENE_SECONDS.stormRain, i);
  });

  const hasGenesis =
    !!data.genesis &&
    ((data.genesis.areas?.length ?? 0) > 0 ||
      (data.genesis.points?.length ?? 0) > 0);
  if (hasGenesis) push("genesis", SCENE_SECONDS.genesis);

  push("outro", SCENE_SECONDS.outro);
  return plan;
}

export function planDurationInFrames(plan: ScenePlanItem[], fps: number): number {
  const total = plan.reduce((acc, s) => acc + s.seconds, 0);
  return Math.round(total * fps);
}

// ─────────────────────────────────────────────────────────────
// Satélite GOES (mismo CDN y estructura que el viewer Tormenta)
// ─────────────────────────────────────────────────────────────
export const MAPBOX_TOKEN =
  "pk.eyJ1IjoiYWxiZXJ0ZWx0aWVtcG8iLCJhIjoiY21rM2pqa29zMGd6NjNncHdlMWZ1NTNlayJ9.0d2lAZ-CmqEuoPe_h2JEHA";
export const MAPBOX_STYLE = "mapbox://styles/mapbox/dark-v11";
export const SAT_FD_BASE = `${CDN}/data/satellite-fd`;

// Vistas full-disk disponibles en el pipeline:
// disco-este | caribe-golfo | mexico-ca | atlantico | disco-oeste | epac
export async function fetchSatelliteView(
  view: string,
  preferredBands: string[] = ["geocolor", "ir"],
  lastN = 18,
  signal?: AbortSignal
): Promise<SatView> {
  try {
    const r = await fetch(`${SAT_FD_BASE}/${view}/manifest.json?ts=${Date.now()}`, {
      signal,
    });
    const vm = await r.json();
    const products: Record<string, SatFrame[]> = vm?.products || {};
    // banda preferida con frames; si ninguna, la primera no vacía del manifest
    let band =
      preferredBands.find((b) => (products[b]?.length ?? 0) > 0) ||
      Object.keys(products).find((b) => (products[b]?.length ?? 0) > 0) ||
      preferredBands[0];
    const all: SatFrame[] = products[band] || [];
    return {
      view,
      band,
      sat: vm?.sat,
      bounds: vm?.bounds || null,
      frames: all.slice(-lastN), // últimas N (3h @ 10min = 18)
    };
  } catch (e) {
    console.warn(`[huracanes] satélite ${view}:`, e);
    return { view, band: preferredBands[0], bounds: null, frames: [] };
  }
}
