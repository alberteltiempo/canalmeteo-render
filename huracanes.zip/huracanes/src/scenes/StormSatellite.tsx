import React from "react";
import { AbsoluteFill } from "remotion";
import { ScenePlaceholder } from "../components/ScenePlaceholder";
import { DataCard } from "../components/DataCard";
import { Storm } from "../types";

// FASE 1: marco + tarjeta de datos real.
// FASE SIGUIENTE: satélite Mapbox+GIBS con flyTo al lon/lat de la tormenta.
export const StormSatellite: React.FC<{ storm: Storm }> = ({ storm }) => {
  return (
    <AbsoluteFill>
      <ScenePlaceholder
        topic="SATÉLITE"
        title={storm.name}
        subtitle="Zoom a la tormenta · animación 3h"
      />
      <DataCard storm={storm} />
    </AbsoluteFill>
  );
};
