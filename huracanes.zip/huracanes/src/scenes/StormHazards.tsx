import React from "react";
import { ScenePlaceholder } from "../components/ScenePlaceholder";
import { BRAND } from "../lib/theme";
import { Storm } from "../types";

// FASE 1: placeholder con los 3 íconos previstos.
// FASE SIGUIENTE: 3 peligros (viento / lluvia / marejada) + recomendaciones
// según el tipo de aviso (ww) activo, con poco texto.
export const StormHazards: React.FC<{ storm: Storm }> = ({ storm }) => {
  return (
    <ScenePlaceholder topic="PELIGROS" topicColor={BRAND.orange} title={storm.name}>
      <div style={{ display: "flex", gap: 56, marginTop: 8 }}>
        {[
          { icon: "💨", label: "Viento" },
          { icon: "🌧️", label: "Lluvia" },
          { icon: "🌊", label: "Marejada" },
        ].map((h) => (
          <div key={h.label} style={{ textAlign: "center" }}>
            <div style={{ fontSize: 84 }}>{h.icon}</div>
            <div style={{ fontSize: 26, fontWeight: 700, marginTop: 8 }}>{h.label}</div>
          </div>
        ))}
      </div>
    </ScenePlaceholder>
  );
};
