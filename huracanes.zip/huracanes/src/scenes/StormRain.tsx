import React from "react";
import { ScenePlaceholder } from "../components/ScenePlaceholder";
import { Storm } from "../types";

// FASE 1: placeholder.
// FASE SIGUIENTE: acumulado 96h. NBM (EEUU) ya en CDN; GFS (México/Caribe) pendiente
// de runner. Conmutar fuente según ubicación de la tormenta; paleta + leyenda comunes.
export const StormRain: React.FC<{ storm: Storm }> = ({ storm }) => {
  return (
    <ScenePlaceholder
      topic="LLUVIA · PRÓXIMOS 4 DÍAS"
      title={storm.name}
      subtitle="Acumulado 96h — NBM (EEUU) / GFS (México y Caribe)"
    />
  );
};
