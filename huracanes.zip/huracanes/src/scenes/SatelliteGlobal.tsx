import React from "react";
import {
  AbsoluteFill,
  interpolate,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { loadFont } from "@remotion/google-fonts/Outfit";
import { SatMap } from "../components/SatMap";
import { SatView } from "../types";

const { fontFamily } = loadFont();

// Vista global del Disco Este: GeoColor (gestiona el terminador día/noche solo).
// Animación de los últimos frames (3h @ 10min) sobre el basemap, igual que Tormenta.
export const SatelliteGlobal: React.FC<{ sat?: SatView }> = ({ sat }) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();

  const fallback: SatView = { view: "disco-este", band: "geocolor", bounds: null, frames: [] };
  const s = sat ?? fallback;

  // Hora ET del frame actualmente visible
  const n = s.frames.length;
  const idx = n
    ? Math.min(n - 1, Math.floor((frame / Math.max(1, durationInFrames - 1)) * (n - 1)))
    : 0;
  const t = n ? new Date(s.frames[idx].time * 1000) : null;
  const hora = t
    ? t.toLocaleTimeString("es-ES", {
        timeZone: "America/New_York",
        hour: "numeric",
        minute: "2-digit",
      }) + " ET"
    : "EN VIVO";

  const titleOpacity = interpolate(frame, [0, 12], [0, 1], { extrapolateRight: "clamp" });

  return (
    <AbsoluteFill style={{ fontFamily, background: "#000" }}>
      {/* Satélite sobre el basemap (vista amplia del trópico) */}
      <SatMap sat={s} center={[-72, 18]} zoom={2.7} opacity={0.92} />

      {/* Degradado superior para legibilidad de los rótulos */}
      <AbsoluteFill
        style={{
          background:
            "linear-gradient(180deg, rgba(0,0,0,0.55) 0%, rgba(0,0,0,0) 22%, rgba(0,0,0,0) 80%, rgba(0,0,0,0.4) 100%)",
          pointerEvents: "none",
        }}
      />

      {/* Barra de tópico */}
      <div
        style={{
          position: "absolute",
          top: 48,
          left: 48,
          display: "flex",
          borderRadius: 10,
          overflow: "hidden",
          boxShadow: "0 6px 24px rgba(0,0,0,0.4)",
          opacity: titleOpacity,
        }}
      >
        <div style={{ background: "#1565c0", padding: "12px 22px", fontWeight: 800, fontSize: 22, color: "#fff" }}>
          SATÉLITE
        </div>
        <div style={{ background: "rgba(13,26,38,0.92)", padding: "12px 22px", fontWeight: 700, fontSize: 22, color: "#fff" }}>
          {s.band === "ir" ? "INFRARROJO · DISCO ESTE" : "GEOCOLOR · DISCO ESTE"}
        </div>
      </div>

      {/* Reloj */}
      <div
        style={{
          position: "absolute",
          top: 48,
          right: 48,
          textAlign: "right",
          opacity: titleOpacity,
          fontFamily: "'JetBrains Mono', monospace",
        }}
      >
        <div style={{ fontSize: 40, fontWeight: 800, color: "#fff", lineHeight: 1 }}>{hora}</div>
        <div style={{ fontSize: 16, color: "rgba(255,255,255,0.65)", marginTop: 4 }}>
          GOES-East · últimas 3 h
        </div>
      </div>
    </AbsoluteFill>
  );
};
