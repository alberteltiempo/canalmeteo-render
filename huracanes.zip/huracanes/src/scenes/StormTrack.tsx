import React from "react";
import { ScenePlaceholder } from "../components/ScenePlaceholder";
import { Storm } from "../types";

// FASE 1: placeholder.
// FASE SIGUIENTE: quitar satélite, dibujar cone + track + points + ww (avisos/vigilancias)
// + arrival, con leyenda de colores unificada (TROP_WW / TROP_CAT).
export const StormTrack: React.FC<{ storm: Storm }> = ({ storm }) => {
  return (
    <ScenePlaceholder
      topic="TRAYECTORIA Y AVISOS"
      title={storm.name}
      subtitle="Cono de incertidumbre · puntos de pronóstico · avisos costeros"
    />
  );
};
