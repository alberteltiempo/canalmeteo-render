import { z } from "zod";

// URLs relativas (al CDN) de las capas GeoJSON por tormenta
export const stormLayersSchema = z
  .object({
    cone: z.string().optional(),
    track: z.string().optional(),
    points: z.string().optional(),
    forecast_radii: z.string().optional(),
    ww: z.string().optional(),
    arrival_earliest: z.string().optional(),
    arrival_likely: z.string().optional(),
    past_swath: z.string().optional(),
    past_track: z.string().optional(),
  })
  .passthrough();

export const stormSchema = z
  .object({
    id: z.string(),
    name: z.string(),
    intensity_kt: z.number().nullable().optional(),
    lon: z.number().nullable().optional(),
    lat: z.number().nullable().optional(),
    last_update: z.string().optional(),
    layers: stormLayersSchema.optional(),
  })
  .passthrough();

export const genesisSchema = z
  .object({
    areas: z.array(z.any()).optional(),
    points: z.array(z.any()).optional(),
  })
  .passthrough();

export const activeStormsSchema = z
  .object({
    updated: z.string().optional(),
    storms: z.array(stormSchema).default([]),
    genesis: genesisSchema.optional(),
  })
  .passthrough();

export type Storm = z.infer<typeof stormSchema>;
export type ActiveStorms = z.infer<typeof activeStormsSchema>;

// ---- Satélite full-disk (data/satellite-fd/{vista}/manifest.json) ----
export type SatFrame = { url: string; time: number };
export type SatBounds = {
  north: number;
  south: number;
  west: number;
  east: number;
};
export type SatView = {
  view: string;
  band: string; // 'geocolor' | 'ir'
  sat?: string; // 'GOES19' | 'GOES18'
  bounds: SatBounds | null;
  frames: SatFrame[];
};

// ---- Plan de escenas (serializable, calculado en calculateMetadata) ----
export type SceneType =
  | "open"
  | "satGlobal"
  | "stormSat"
  | "stormTrack"
  | "stormHazard"
  | "stormRain"
  | "genesis"
  | "outro";

export type ScenePlanItem = {
  id: string;
  type: SceneType;
  seconds: number;
  stormIndex?: number;
};

// Props de la composición principal
export const tropicoPropsSchema = z.object({
  data: activeStormsSchema.optional(),
  plan: z.array(z.any()).optional(),
  sat: z.any().optional(),
});

export type TropicoProps = {
  data: ActiveStorms;
  plan: ScenePlanItem[];
  sat?: SatView;
};
