import React from "react";
import { AbsoluteFill, Series, useVideoConfig } from "remotion";
import { TropicoProps } from "./types";
import { Open } from "./components/Open";
import { Outro } from "./components/Outro";
import { SatelliteGlobal } from "./scenes/SatelliteGlobal";
import { StormSatellite } from "./scenes/StormSatellite";
import { StormTrack } from "./scenes/StormTrack";
import { StormHazards } from "./scenes/StormHazards";
import { StormRain } from "./scenes/StormRain";
import { GenesisAreas } from "./scenes/GenesisAreas";

export const TropicoSegment: React.FC<TropicoProps> = ({ data, plan, sat }) => {
  const { fps } = useVideoConfig();
  const storms = data?.storms || [];

  return (
    <AbsoluteFill style={{ backgroundColor: "#0d1a26" }}>
      <Series>
        {(plan || []).map((s) => {
          const dur = Math.max(1, Math.round(s.seconds * fps));
          const storm =
            s.stormIndex != null ? storms[s.stormIndex] : undefined;
          return (
            <Series.Sequence key={s.id} durationInFrames={dur}>
              {renderScene(s.type, storm, data, sat)}
            </Series.Sequence>
          );
        })}
      </Series>
    </AbsoluteFill>
  );
};

function renderScene(
  type: string,
  storm: any,
  data: any,
  sat: any
): React.ReactNode {
  switch (type) {
    case "open":
      return <Open />;
    case "satGlobal":
      return <SatelliteGlobal sat={sat} />;
    case "stormSat":
      return storm ? <StormSatellite storm={storm} /> : null;
    case "stormTrack":
      return storm ? <StormTrack storm={storm} /> : null;
    case "stormHazard":
      return storm ? <StormHazards storm={storm} /> : null;
    case "stormRain":
      return storm ? <StormRain storm={storm} /> : null;
    case "genesis":
      return <GenesisAreas data={data} />;
    case "outro":
      return <Outro />;
    default:
      return null;
  }
}
