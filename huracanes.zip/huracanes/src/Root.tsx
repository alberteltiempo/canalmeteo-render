import React from "react";
import { Composition } from "remotion";
import { TropicoSegment } from "./TropicoSegment";
import {
  fetchActiveStorms,
  fetchSatelliteView,
  buildScenePlan,
  planDurationInFrames,
} from "./lib/cdn";
import type { ActiveStorms, ScenePlanItem, SatView } from "./types";

const FPS = 30;
const WIDTH = 1920;
const HEIGHT = 1080;

export const Root: React.FC = () => {
  return (
    <Composition
      id="TropicoSegment"
      component={TropicoSegment as any}
      durationInFrames={FPS * 30} // provisional; lo fija calculateMetadata
      fps={FPS}
      width={WIDTH}
      height={HEIGHT}
      defaultProps={{
        data: { storms: [] } as ActiveStorms,
        plan: [] as ScenePlanItem[],
        sat: undefined as SatView | undefined,
      }}
      calculateMetadata={async ({
        props,
        abortSignal,
      }: {
        props: { data: ActiveStorms; plan: ScenePlanItem[]; sat?: SatView };
        abortSignal: AbortSignal;
      }) => {
        const [data, sat] = await Promise.all([
          fetchActiveStorms(abortSignal),
          fetchSatelliteView("disco-este", ["geocolor", "ir"], 18, abortSignal),
        ]);
        const plan = buildScenePlan(data);
        const durationInFrames = planDurationInFrames(plan, FPS);
        // eslint-disable-next-line no-console
        console.log(
          `[huracanes] ${data.storms.length} tormenta(s) · ${plan.length} escenas · ` +
            `${sat.frames.length} frames satélite · ${(durationInFrames / FPS).toFixed(1)}s`
        );
        return {
          durationInFrames,
          fps: FPS,
          width: WIDTH,
          height: HEIGHT,
          props: { ...props, data, plan, sat },
        };
      }}
    />
  );
};
