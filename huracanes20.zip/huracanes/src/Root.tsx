import React from "react";
import { Composition } from "remotion";
import { TropicoSegment } from "./TropicoSegment";
import {
  fetchActiveStorms,
  enrichStorms,
  fetchSatelliteData,
  fetchPrecipManifests,
  attachPrecip,
  buildScenePlan,
  planDurationInFrames,
} from "./lib/cdn";
import type { ActiveStorms, ScenePlanItem, SatData } from "./types";

const FPS = 30;
const WIDTH = 1920;
const HEIGHT = 1080;

export const Root: React.FC = () => {
  return (
    <Composition
      id="TropicoSegment"
      component={TropicoSegment as any}
      durationInFrames={FPS * 30} // provisional; lo fija calculateMetadata
      fps={FPS}
      width={WIDTH}
      height={HEIGHT}
      defaultProps={{
        data: { storms: [] } as ActiveStorms,
        plan: [] as ScenePlanItem[],
        sat: undefined as SatData | undefined,
      }}
      calculateMetadata={async ({
        props,
        abortSignal,
      }: {
        props: { data: ActiveStorms; plan: ScenePlanItem[]; sat?: SatData };
        abortSignal: AbortSignal;
      }) => {
        const [rawData, sat, precipManifests] = await Promise.all([
          fetchActiveStorms(abortSignal),
          fetchSatelliteData("disco-este", ["geocolor"], 36, abortSignal),
          fetchPrecipManifests(abortSignal),
        ]);
        const enriched = await enrichStorms(rawData, abortSignal);
        const data = attachPrecip(enriched, precipManifests);
        const plan = buildScenePlan(data);
        const durationInFrames = planDurationInFrames(plan, FPS);
        const satN = sat.bands?.geocolor?.length ?? sat.bands?.ir?.length ?? 0;
        const rainModels = data.storms
          .map((s) => s._precip?.model)
          .filter(Boolean)
          .join(", ");
        // eslint-disable-next-line no-console
        console.log(
          `[huracanes] ${data.storms.length} tormenta(s) · ${plan.length} escenas · ` +
            `${satN} frames satélite · lluvia: ${rainModels || "—"} · ` +
            `${(durationInFrames / FPS).toFixed(1)}s`
        );
        return {
          durationInFrames,
          fps: FPS,
          width: WIDTH,
          height: HEIGHT,
          props: { ...props, data, plan, sat },
        };
      }}
    />
  );
};
