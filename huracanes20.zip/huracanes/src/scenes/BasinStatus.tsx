import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { loadFont } from "@remotion/google-fonts/Outfit";
import { SatMap } from "../components/SatMap";
import { TopicBar } from "../components/Overlay";
import { satViewFromBand, BASIN_VIEW } from "../lib/cdn";
import { BRAND } from "../lib/theme";
import { SatData, Basin } from "../types";

const { fontFamily } = loadFont();

const BASIN_NAME: Record<Basin, string> = {
  atlantic: "Cuenca Atlántica",
  epac: "Cuenca del Pacífico Oriental",
};

// Slide al cierre de una cuenca: GeoColor encuadrado a la cuenca + caja centrada.
//  - mode "none": "No hay tormentas activas"
//  - mode "monitoring": "Zona en vigilancia" (el NHC monitorea desarrollo)
export const BasinStatus: React.FC<{
  basin: Basin;
  sat?: SatData;
  mode: "none" | "monitoring";
}> = ({ basin, sat, mode }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const view = satViewFromBand(sat, "geocolor");
  const box = BASIN_VIEW[basin];
  const center: [number, number] = [(box[0][0] + box[1][0]) / 2, (box[0][1] + box[1][1]) / 2];

  const op = interpolate(frame, [0, 12], [0, 1], { extrapolateRight: "clamp" });
  const cardIn = spring({ frame: frame - 6, fps, config: { damping: 16 } });
  const cardScale = interpolate(cardIn, [0, 1], [0.9, 1]);

  const monitoring = mode === "monitoring";
  const accent = monitoring ? BRAND.orange : "#2ecc71";
  const title = monitoring ? "Zona en vigilancia" : "No hay tormentas activas";
  const sub = monitoring
    ? "El NHC monitorea una posible zona de desarrollo"
    : `${BASIN_NAME[basin]} · sin sistemas tropicales`;

  return (
    <AbsoluteFill style={{ fontFamily, background: "#000" }}>
      <SatMap
        sat={view}
        center={center}
        zoom={3.4}
        fitBounds={box}
        fitPadding={{ top: 120, bottom: 120, left: 90, right: 90 }}
        opacity={op}
      />

      <TopicBar topic="TRÓPICO" sub={BASIN_NAME[basin].toUpperCase()} opacity={op} />

      {/* Caja centrada */}
      <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
        <div
          style={{
            opacity: op,
            transform: `scale(${cardScale})`,
            background: "rgba(13,26,38,0.9)",
            border: "1px solid rgba(255,255,255,0.14)",
            borderRadius: 22,
            padding: "40px 64px",
            textAlign: "center",
            boxShadow: "0 20px 60px rgba(0,0,0,0.55)",
            maxWidth: 1100,
          }}
        >
          <div
            style={{
              width: 120,
              height: 8,
              borderRadius: 4,
              background: accent,
              margin: "0 auto 24px",
            }}
          />
          <div style={{ fontSize: 64, fontWeight: 800, color: "#fff", lineHeight: 1.05 }}>
            {title}
          </div>
          <div style={{ fontSize: 30, color: "rgba(255,255,255,0.82)", marginTop: 16 }}>{sub}</div>
        </div>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
