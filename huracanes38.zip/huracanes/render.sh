#!/usr/bin/env bash
set -euo pipefail

# Render del segmento "Vistazo al Trópico" -> Tropico_2026.mp4
# Alineado con parques-webcams: --scale=1 (1920x1080), --concurrency=3 en sfo3-c.
# (concurrency=4 provoca OOM en la droplet de 3.8 GB)

cd "$(dirname "$0")"

OUTPUT_DIR="${OUTPUT_DIR:-out}"
mkdir -p "$OUTPUT_DIR"
OUTPUT_FILE="$OUTPUT_DIR/Tropico_2026.mp4"
CONCURRENCY="${CONCURRENCY:-3}"

# Limpiar caché de bundle si hubo cambios (evita el fallo silencioso de ~30s)
# rm -rf /tmp/remotion-webpack-bundle-* /tmp/remotion-v4.0.452-assets* 2>/dev/null || true

npx remotion render TropicoSegment "$OUTPUT_FILE" \
  --gl=swangle \
  --scale=1 \
  --concurrency="$CONCURRENCY"

echo "OK -> $OUTPUT_FILE"
# TODO: subir a Dropbox /Playout/RenderFarm/TROPICO.mp4 + CDN, como en parques render.sh
